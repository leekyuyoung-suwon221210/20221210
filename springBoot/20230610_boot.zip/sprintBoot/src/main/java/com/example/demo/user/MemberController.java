package com.example.demo.user;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping("/member")
public class MemberController {
	private final MemberService memberService;
	
	// 회원가입 - 사용자에게 정보받아서 Member 테이블에 insert
	@GetMapping("/signup")
	public String signup(MemberForm memberForm) {		
		return "signup";
	}
	
	@PostMapping("/signup")
	public String signupPost(@Valid MemberForm mf, BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			return "signup";
		}
		if(!mf.getPassword().equals(mf.getConfirmPassword())) {
			bindingResult.rejectValue("confirmPassword", "passwordIncorrect",
					"패스워드가 일치하지 않습니다.");
			return "signup";
		}
		Member member = new Member();
		member.setEmail(mf.getEmail());
		member.setPassword(mf.getPassword());
		member.setUserName(mf.getUserName());
		memberService.create(member);
		
		return "redirect:/";
	}
	
	
	// 회원탈퇴 - 삭제
	// 로그인 - 조회했는데. 성공
	// 로그아웃 - 
	

}
