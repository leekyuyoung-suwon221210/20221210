package com.example.demo.member;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class MemberService {	
	private final MemberRepository memberRepository;
	private final PasswordEncoder passwordEncoder;  
	
	public void create(Member member) {
		member.setPassword(passwordEncoder.encode(member.getPassword()));		
		memberRepository.save(member);		
	}


	public Member findByEmailAndPassword(String email, String password) {
		// TODO Auto-generated method stub
		return memberRepository.findByEmailAndPassword(email,password);
	}
	

}
