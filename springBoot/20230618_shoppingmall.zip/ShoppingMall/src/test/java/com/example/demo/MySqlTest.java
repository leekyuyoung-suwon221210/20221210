package com.example.demo;

import java.time.LocalDateTime;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import com.example.demo.constant.ItemSellStatus;
import com.example.demo.entity.Item;
import com.example.demo.repository.ItemRepository;
@SpringBootTest
//@TestPropertySource(locations = "classpath:application.properties")
class MySqlTest {

	@Autowired
	ItemRepository itemRepository;
	
	@Test
	@DisplayName("상품저장테스트")
	void createItemTest() {
		for (int i = 0; i < 10; i++) {
			Item item = new Item();
			item.setItemNm("테스트상품 "+i);
			item.setPrice(10000 + Integer.valueOf(i));
			item.setItemDetail("테스트상품설명 "+i);
			item.setStockNumber(100+ Integer.valueOf(i));
			item.setRegTime(LocalDateTime.now());
			item.setUpdateTime(LocalDateTime.now());
			item.setItemSellStatus(ItemSellStatus.SELL);
			itemRepository.save(item);			
		}
	}

}
