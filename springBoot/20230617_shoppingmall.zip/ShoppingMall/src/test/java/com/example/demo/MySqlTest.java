package com.example.demo;

import java.time.LocalDateTime;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import com.example.demo.constant.ItemSellStatus;
import com.example.demo.entity.Item;
import com.example.demo.repository.ItemRepository;
@SpringBootTest
//@TestPropertySource(locations = "classpath:application.properties")
class MySqlTest {

	@Autowired
	ItemRepository itemRepository;
	
	@Test
	@DisplayName("상품저장테스트")
	void createItemTest() {
		Item item = new Item();
		item.setItemNm("테스트상품");
		item.setPrice(10000);
		item.setItemDetail("테스트상품설명");
		item.setStockNumber(100);
		item.setRegTime(LocalDateTime.now());
		item.setUpdateTime(LocalDateTime.now());
		item.setItemSellStatus(ItemSellStatus.SELL);
		itemRepository.save(item);
	}

}
