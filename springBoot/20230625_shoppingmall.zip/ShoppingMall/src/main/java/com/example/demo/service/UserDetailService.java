package com.example.demo.service;

import org.springframework.security.core.userdetails.UserDetails;

public interface UserDetailService {
	// UserDetail 사용자의 정보과 권한을 갖음
	public UserDetails loadUserByUsername(String email); // 회원정보를 조회

}
