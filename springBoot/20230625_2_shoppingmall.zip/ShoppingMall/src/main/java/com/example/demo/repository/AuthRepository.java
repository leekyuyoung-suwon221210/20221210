package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.constant.Role;
import com.example.demo.entity.Auth;

public interface AuthRepository extends JpaRepository<Auth, Long> {
	public Auth findByAuthRole(Role role);
}
