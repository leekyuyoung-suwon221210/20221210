package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.constant.Role;
import com.example.demo.entity.Auth;
import com.example.demo.repository.AuthRepository;

@SpringBootTest
public class CreateAuth {
	@Autowired
	private AuthRepository authRepository;
	
	@Test
	public void test1() {
		Auth a = new Auth();
		a.setAuthRole(Role.USER);
		authRepository.save(a);
		
		a = new Auth();
		a.setAuthRole(Role.ADMIN);
		authRepository.save(a);
		
		a = new Auth();
		a.setAuthRole(Role.MANGER);
		authRepository.save(a);
		
	}
	

}
