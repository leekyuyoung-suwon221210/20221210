package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.demo.constant.Role;
import com.example.demo.dto.MemberFormDto;
import com.example.demo.entity.Auth;
import com.example.demo.entity.Member;
import com.example.demo.repository.AuthRepository;
import com.example.demo.repository.MemberRepository;

@SpringBootTest
public class CreateMember {
	@Autowired
	MemberRepository memberRepository;
	
	@Autowired
	AuthRepository authRepository;
	
	@Autowired
	PasswordEncoder passwordEncorder;
	
	@Test
	public void test1() {
		Auth auth =  authRepository.findByAuthRole(Role.USER);
		Member m = new Member();
		m.setAddress("");
		m.setAuth(auth);
		m.setEmail("456@abc.com");
		m.setName("홍길동2");
		String password = passwordEncorder.encode("1234");
		m.setPassword(password);
		memberRepository.save(m);
	}

}
