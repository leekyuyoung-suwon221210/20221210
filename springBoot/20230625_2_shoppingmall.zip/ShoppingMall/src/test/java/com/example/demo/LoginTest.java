package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.demo.entity.Member;
import com.example.demo.repository.MemberRepository;

@SpringBootTest
public class LoginTest {
	@Autowired
	MemberRepository memberRepository;
	@Autowired
	PasswordEncoder passwordEncorder;
	
	@Test
	public void loginTest() {
		Member member =  memberRepository.findByEmail("123@abc.com");		
		assertTrue(passwordEncorder.matches("1234", member.getPassword() ));		
	}

}
