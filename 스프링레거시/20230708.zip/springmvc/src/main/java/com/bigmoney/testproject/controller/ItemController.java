package com.bigmoney.testproject.controller;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bigmoney.testproject.service.ItemService;

@Controller
public class ItemController {

	@Autowired
	ItemService itemService;
	
	@RequestMapping(value = "/create" ,method = RequestMethod.GET)
	public ModelAndView create() {
		return new ModelAndView("item/create");
	}
	@RequestMapping(value = "/create" ,method = RequestMethod.POST)
	public ModelAndView createPost(@RequestParam Map<String,Object> map) 
	{
		ModelAndView mav = new ModelAndView();		
		String id = itemService.insert(map);
		if(id == null)
			mav.setViewName("redirect:/create");
		else
			mav.setViewName("redirect:/detail?id="+id);
		return mav;
	}
	@GetMapping("/detail")
	public ModelAndView detail(@RequestParam Map<String, Object> map) {
		Map<String, Object> detailMap =  itemService.detail(map);
		ModelAndView mv = new ModelAndView();
		mv.addObject("data", detailMap);
		mv.setViewName("/item/detail");
		return mv;
		
	}
	
	
	
	
	
	@GetMapping(value = "/select")
	public ModelAndView select() {
		List<Map<String, Object>> allItems =  itemService.selectAll();
		
		// 디버깅용
		Consumer<Map<String, Object>> c = x -> {
			System.out.printf("%s %s %s %s \n", 
					x.get("id"), x.get("item_name"),x.get("f_id"),x.get("price"));
		};
		
		for (Map<String, Object> map : allItems) {
			c.accept(map);
		}
		ModelAndView mv = new ModelAndView();
		mv.addObject("allItems", allItems);
		mv.setViewName("item/lists");
		return mv;
	}
	
}
