package com.bigmoney.testproject.service;

import java.util.Map;

public interface MemberService {

	boolean getMember(Map<String, Object> map);

}
