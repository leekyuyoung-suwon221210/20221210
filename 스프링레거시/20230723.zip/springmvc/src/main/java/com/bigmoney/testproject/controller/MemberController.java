package com.bigmoney.testproject.controller;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.mail.Transport;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bigmoney.testproject.service.MemberService;

@Controller
public class MemberController {
	@Autowired
	MemberService memberService;
	
	@Autowired
	JavaMailSenderImpl mailSender;
	
	private String strRand;
	
	@GetMapping("/login")
	public ModelAndView login() {
		return new ModelAndView("/member/login");
	}
	
//	@PostMapping("/login")
	@ResponseBody
	public String login_post(@RequestParam Map<String, Object> map,
		HttpServletRequest req ) throws Exception {
		
		boolean isMember =  memberService.getMember(map);
		HttpSession session =  req.getSession();
		if(isMember) {
			session.setAttribute("email", map.get("email"));
			return "success";
		}
		throw new Exception("濡쒓렇�븘�썐 �떎�뙣");			
	}
	
	@PostMapping("/logout")
	@ResponseBody
	public String logout(HttpServletRequest req) {
		HttpSession session =  req.getSession();
		session.invalidate();
		return "success";
	}
	
	@GetMapping("/regist")
	public ModelAndView regist() {
		return new ModelAndView("/member/regist");
	}
	
	@PostMapping("/checklogin")
	@ResponseBody
	public String checklogin(@RequestBody String email) throws Exception {
		String decodeEmail =  URLDecoder.decode(email,StandardCharsets.UTF_8);
		decodeEmail  =decodeEmail.replace("=", "");
		Map<String, Object> map = new HashMap<String, Object>();
		System.out.println(decodeEmail);
		map.put("email", decodeEmail);
		boolean isMember =  memberService.getMember(map);
		if(isMember)		
			return "true";
		else
			return "false";
	}
	
	@GetMapping("/find")
	public ModelAndView find() {
		return new ModelAndView("/member/findpsw");
	}
	
	@PostMapping("/find")
	@ResponseBody
	public String find_post(@RequestParam Map<String, Object> map,
		HttpServletRequest req ) throws Exception {
		// �옒�뜡�븳 4�옄由ъ닽�옄瑜� 臾몄옄�뿴�쓣 �쟾�떖諛쏆� 硫붿씪 二쇱냼濡� 蹂대궦�떎.
		String sendToEmail = (String) map.get("email");
		
		
		Random rand = new Random();
		strRand="";
		for (int i = 0; i < 4; i++) {
			strRand+=rand.nextInt(10);			
		}
		
		try {
			MailUtils sendMail = new MailUtils(mailSender);
			sendMail.setSubject("�쉶�썝媛��엯 �씠硫붿씪 �씤利�");
			String message = new StringBuffer()
			.append("<h1>[�씠硫붿씪 �씤利�]諛쒖떊�쟾�슜�씠誘�濡� �쉶�떊 遺덇�</h1>")
			.append("<p>�씤利앸쾲�샇 : ")
			.append(strRand)
			.append("</p>")
			.toString();		
			
			sendMail.setText(message);
			sendMail.setFrom("suwon221210@gmail.com", "愿�由ъ옄");
			sendMail.setTo(sendToEmail);  // 諛쏆쓣二쇱냼
			sendMail.send();			
		} catch (Exception e) {			
			e.printStackTrace();
			return e.getMessage();
		}
		return "success";
	}
	
	@PostMapping("/checknum")
	@ResponseBody
	public String checknum(@RequestBody  String str) {
		str = str.replace("=", "");
		if (str.equals(strRand))
			return "success";
		else 
			return "faile";		
	}
	
}
