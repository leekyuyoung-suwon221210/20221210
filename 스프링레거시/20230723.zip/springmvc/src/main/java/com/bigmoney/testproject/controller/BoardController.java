package com.bigmoney.testproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BoardController {

	@RequestMapping(value = "/faq" ,method = RequestMethod.GET)
	public ModelAndView faq() {
		return new ModelAndView("board/faq");
	}
	
	@RequestMapping(value = "/faq2" ,method = RequestMethod.GET)
	public ModelAndView faq2() {
		return new ModelAndView("board/faq2");
	}
	
	
	@RequestMapping(value = "/qna" ,method = RequestMethod.GET)
	public ModelAndView qna() {
		return new ModelAndView("board/qna");
	}
	
	@RequestMapping(value = "/qna_detail" ,method = RequestMethod.GET)
	public ModelAndView qna_detail() {
		return new ModelAndView("board/qna_detail");
	}
	
	@RequestMapping(value = "/board3" ,method = RequestMethod.GET)
	public ModelAndView board3() {
		return new ModelAndView("board/board_accordion");
	}
	
	@RequestMapping(value = "/board4" ,method = RequestMethod.GET)
	public ModelAndView board4() {
		return new ModelAndView("board/board_table");
	}
}
