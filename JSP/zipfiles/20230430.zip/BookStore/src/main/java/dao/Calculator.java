package dao;

public class Calculator {
	public int myMethod(int n) {
		return n*n*n;
	}
}
