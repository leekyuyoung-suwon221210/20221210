package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import dto.Product;

public class ProductRepository {

	private ArrayList<Product> listOfProducts = new ArrayList<Product>();		

	public ProductRepository() {
		try {
			Connection con = ConnectionDb.getConnection();
			Statement stmt =  con.createStatement();  // 쿼리 실행
			String sql = "select * from product";
			ResultSet rs =  stmt.executeQuery(sql);		
			
			while (rs.next()) {
				Product p = new Product(					
					rs.getString("productId"),
					rs.getString("pname"),
					rs.getInt("unitPrice"),
					rs.getString("descriptions"),
					rs.getString("manufacturer"),
					rs.getString("category"),
					rs.getLong("unitsInStock"),
					rs.getString("conditions"),
					rs.getString("filename")
				);
				listOfProducts.add(p);
			}
		} catch (Exception e) {}
		
	}

	public ArrayList<Product> getAllProducts() {
		return listOfProducts;
	}
	
	public Product getProductById(String productId) {
		Product productById = null;

		for (int i = 0; i < listOfProducts.size(); i++) {
			Product product = listOfProducts.get(i);
			if (product != null && product.getProductId() != null && product.getProductId().equals(productId)) {
				productById = product;
				break;
			}
		}
		return productById;
	}
	
	public void addProduct(Product product) {
		listOfProducts.add(product);
	}
}
