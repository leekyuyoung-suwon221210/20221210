package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.Product;

public class ProductRepository {

	private ArrayList<Product> listOfProducts = new ArrayList<Product>();		

	public ProductRepository() {
		try {
			Connection con = ConnectionDb.getConnection();
			Statement stmt =  con.createStatement();  // 쿼리 실행
			String sql = "select * from product";
			ResultSet rs =  stmt.executeQuery(sql);		
			
			while (rs.next()) {
				Product p = new Product(					
					rs.getString("productId"),
					rs.getString("pname"),
					rs.getInt("unitPrice"),
					rs.getString("descriptions"),
					rs.getString("manufacturer"),
					rs.getString("category"),
					rs.getLong("unitsInStock"),
					rs.getString("conditions"),
					rs.getString("filename")
				);
				listOfProducts.add(p);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
		}
		
	}

	public ArrayList<Product> getAllProducts() {
		return listOfProducts;
	}
	
	public Product getProductById(String productId) {		
		Product p = null;		
		try {
			Connection con = ConnectionDb.getConnection();
			String sql = "select * from product where productId = ?";			
			PreparedStatement pstmt =  con.prepareStatement(sql);
			pstmt.setString(1, productId);
			ResultSet rs =  pstmt.executeQuery();
			if(rs.next()) {
				p = new Product(					
						rs.getString("productId"),
						rs.getString("pname"),
						rs.getInt("unitPrice"),
						rs.getString("descriptions"),
						rs.getString("manufacturer"),
						rs.getString("category"),
						rs.getLong("unitsInStock"),
						rs.getString("conditions"),
						rs.getString("filename")
					);
			}
		} catch (ClassNotFoundException | SQLException e) {			
			e.printStackTrace();
		}
		return p;
		
	}
	
	public void addProduct(Product product) {
		listOfProducts.add(product);
	}
}
